package com.talentyco

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ProyectoEmptyMavenKotlinApplicationTests {

	@Test
	void contextLoads() {
	}

}
