package com.talentyco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoEmptyMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoEmptyMavenApplication.class, args);
	}

}
