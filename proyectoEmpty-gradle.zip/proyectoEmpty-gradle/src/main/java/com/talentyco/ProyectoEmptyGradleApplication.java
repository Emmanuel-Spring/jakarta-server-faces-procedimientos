package com.talentyco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoEmptyGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoEmptyGradleApplication.class, args);
	}

}
